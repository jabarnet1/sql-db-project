import { BrowserRouter, Routes, Route } from "react-router-dom";
import { CssBaseline, ThemeProvider } from '@mui/material'
import { indigo, amber } from '@mui/material/colors'
import { createTheme } from "@mui/material/styles";
import { useNavigate } from 'react-router-dom'; 


import NavBar from './components/NavBar';
import LandingPage from './pages/LandingPage'; 
import StandingsPage from './pages/StandingsPage';
import TeamRosterPage from "./pages/TeamRosterPage";
import PlayerProfilePage from "./pages/PlayerProfilePage";
import TeamPage from './pages/TeamPage'; //MO test
import TeamSeasonPerformance from './pages/TeamSeasonPerformance';
import TeamHeadToHeadPage from './pages/TeamHeadToHeadPage';


// createTheme enables you to customize the look and feel of your app past the default
// in this case, we only change the color scheme
export const theme = createTheme({
  palette: {
    primary: indigo,
    secondary: amber,
  },
});


// App is the root component of our application and as children contain all our pages
// We use React Router's BrowserRouter and Routes components to define the pages for
// our application, with each Route component representing a page and the common
// NavBar component allowing us to navigate between pages (with hyperlinks)
export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/standings" element={<StandingsPage />} />
          <Route path="/teams/:team_id/roster" element={<TeamRosterPage />} />
          <Route path="/players/:pid/profile" element={<PlayerProfilePage />} />
          <Route path="/TeamPage/:team_id" element={<TeamPage />} /> 
          <Route path="/team-performance" element={<TeamSeasonPerformance />} />
          <Route path="/team-head-to-head" element={<TeamHeadToHeadPage />} /> 
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}