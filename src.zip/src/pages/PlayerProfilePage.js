import { useEffect, useState } from 'react';
import { Container } from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';

const config = require('../config.json');

export default function PlayerProfilePage() {
  const { pid } = useParams(); // <-- correctly matches :pid from the route
  const [profile, setProfile] = useState(null);
  const [season, setSeason] = useState('20192020');

  const navigate = useNavigate();

  const handleSeasonChange = (event) => {
    setSeason(event.target.value);
    console.log("Season selected:", event.target.value);
  };

  useEffect(() => {
    if (pid) {
      fetch(`http://${config.server_host}:${config.server_port}/players/${pid}`)
        .then((res) => res.json())
        .then((resJson) => {
          console.log("Fetched profile:", resJson);
          setProfile(resJson);
        })
        .catch((err) => console.error("Error fetching player profile:", err));
    }
  }, [pid]);

  return (
    <Container>
      <label htmlFor="season">Choose a season: </label>
      <select id="season" name="season" value={season} onChange={handleSeasonChange}>
        <option value="20182019">2018–2019</option>
        <option value="20192020">2019–2020</option>
      </select>

      {profile ? (
        <>
          <h2>Season: {season.slice(0, 4)}–{season.slice(4)}</h2>
          <h1 style={{ fontSize: 32 }}>Player ID: {profile.player_id}</h1>
          <h1 style={{ fontSize: 32 }}>First Name: {profile.firstname}</h1>
          <h1 style={{ fontSize: 32 }}>Last Name: {profile.lastname}</h1>
          <h1 style={{ fontSize: 32 }}>Nationality: {profile.nationality}</h1>
          <h1 style={{ fontSize: 32 }}>Birth City: {profile.birthcity}</h1>
          <h1 style={{ fontSize: 32 }}>Primary Position: {profile.primaryposition}</h1>
          <h1 style={{ fontSize: 32 }}>Birthdate: {profile.birthdate}</h1>
          <h1 style={{ fontSize: 32 }}>Height: {profile.height}</h1>
          <h1 style={{ fontSize: 32 }}>Height (cm): {profile.height_cm}</h1>
          <h1 style={{ fontSize: 32 }}>Weight: {profile.weight}</h1>
          <h1 style={{ fontSize: 32 }}>Shot: {profile.shootscatches}</h1>
        </>
      ) : (
        <h2>Loading player profile...</h2>
      )}
    </Container>
  );
}
