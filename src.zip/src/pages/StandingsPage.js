import { useEffect, useState } from 'react';
import { Button, Checkbox, Container, FormControlLabel, Grid, Link, Slider, TextField } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';

import { useNavigate } from 'react-router-dom';
import { useSearchParams } from 'react-router-dom';
const config = require('../config.json');

export default function StandingsPage() {
  const [pageSize, setPageSize] = useState(10);
  const [data, setData] = useState([]);
  const [title, setTitle] = useState('');
  const [season, setSeason] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState(null);
  const navigate = useNavigate();

  //const [searchParams] = useSearchParams();
  //setSeason(searchParams.get('season'));

  const handleSeasonChange = (season) => {
    setSeason(season);
    console.log(season);
 }

  const handleRowClick = (params) => {
  const team_Id = params.row.team;
  navigate(`/teams/${team_Id}/roster`);
  console.log(team_Id);
};


  useEffect(() => {

    if (season) {
    fetch(`http://${config.server_host}:${config.server_port}/standings?season=${season}`)
      .then(res => res.json())
      .then(resJson => {
        const standingsWithSeason = resJson.map((standings) => ({ team: standings.team,
                                                                  season: standings.season,
                                                                  shortname: standings.shortname,
                                                                  teamname: standings.teamname,
                                                                  GP: standings.gp,
                                                                  W: standings.w,
                                                                  L: standings.l,
                                                                  OTL: standings.otl,
                                                                  GF: standings.gf,
                                                                  GA: standings.ga,
                                                                  plus_minus: standings.plus_minus,
                                                                  Pts: standings.pts  }));
        setData(standingsWithSeason);
        console.log(season);
      })
    }
  }, [season]);

  const seasons = data.map(item => item.season);
  let currentSeason = 0;

  if (seasons[0] != null) {
    currentSeason = seasons[0].slice(0, 4) + "-" + seasons[0].slice(4);
  }

  const columns = [
    { field: 'team', headerName: 'Team ID' },
    { field: 'shortname', headerName: 'Home' },
    { field: 'teamname', headerName: 'Team', renderCell: (params) => (
      <Link onClick={() => setSelectedTeamId(params.row.team)}>{params.value} </Link>)},
    { field: 'GP', headerName: 'Games Played' },
    { field: 'W', headerName: 'Wins' },
    { field: 'L', headerName: 'Losses' },
    { field: 'OTL', headerName: 'Overtime Losses' },
    { field: 'GF', headerName: 'Goals For' },
    { field: 'GA', headerName: 'Goals Against' },
    { field: 'plus_minus', headerName: 'Plus Minus' },
    { field: 'Pts', headerName: 'Points' }
  ]


    return (
    <Container>
      
      <label for="season">Choose a season: </label> 
      <select id="season" name="season" value={season} onChange={event => handleSeasonChange(event.target.value)}>
            <option value="20182019" >20182019</option>
            <option value="20192020" >20192020</option>
      </select>
      <h2>Season: {currentSeason}
      </h2>

      {/* Notice how similar the DataGrid component is to our LazyTable! What are the differences? */}
      <DataGrid
        rows={data}
        columns={columns}
        pageSize={pageSize}
        rowsPerPageOptions={[5, 10, 25]}
        onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
        getRowId={(row) => row.team}
        onRowClick={handleRowClick}
      />
    </Container>
  );
}