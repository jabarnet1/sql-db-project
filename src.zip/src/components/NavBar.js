// src/components/NavBar.js
import React from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import { Link } from 'react-router-dom';

export default function NavBar() {
  return (
    <AppBar position="sticky">
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          NHL Stats App
        </Typography>
        <Button color="inherit" component={Link} to="/">
          Home
        </Button>
        <Button color="inherit" component={Link} to="/standings">
          Standings
        </Button>
        <Button color="inherit" component={Link} to="/teams/:team_id/roster">
          Team Roster
        </Button>
      </Toolbar>
    </AppBar>
  );
}